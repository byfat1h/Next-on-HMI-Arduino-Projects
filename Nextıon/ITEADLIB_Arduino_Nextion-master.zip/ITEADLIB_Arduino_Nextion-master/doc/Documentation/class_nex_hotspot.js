var class_nex_hotspot =
[
    [ "NexHotspot", "class_nex_hotspot.html#ad2408e74f5445941897702c4c78fddbf", null ]
];