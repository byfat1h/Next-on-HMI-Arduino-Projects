var class_nex_checkbox =
[
    [ "NexCheckbox", "class_nex_checkbox.html#a8aa4ea60796bdce0de0de3dd675ef56a", null ],
    [ "Get_background_color_bco", "class_nex_checkbox.html#abca30f46ecb7a4c88d816af85fa7f777", null ],
    [ "Get_font_color_pco", "class_nex_checkbox.html#a93fbcf8796f156e6700ebf3e13abfce6", null ],
    [ "getValue", "class_nex_checkbox.html#a6832110a49f9bbbb14a54f36db020d44", null ],
    [ "Set_background_color_bco", "class_nex_checkbox.html#ab430ba5908c84fea8ab910002581350a", null ],
    [ "Set_font_color_pco", "class_nex_checkbox.html#aa1d52cc0170f11ec85263770fe77db2a", null ],
    [ "setValue", "class_nex_checkbox.html#aa932e7c45765400618dce1804766264b", null ]
];